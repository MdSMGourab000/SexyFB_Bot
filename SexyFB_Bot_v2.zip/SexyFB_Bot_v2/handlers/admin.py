from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.enums import ParseMode

from config import settings
from database import db
from keyboards.inline import admin_panel_kb, back_main_kb
from utils.zenex import zenex

router = Router()


class AdminStates(StatesGroup):
    waiting_user_id = State()
    waiting_amount = State()
    waiting_price_country = State()
    waiting_price_value = State()


def is_admin(user_id: int) -> bool:
    return user_id in settings.admin_ids


@router.callback_query(F.data == "admin_panel")
async def admin_panel(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("Access denied", show_alert=True)
        return
    await callback.message.edit_text(
        "<b>🛡 Admin Panel</b>\n\nSelect action:",
        reply_markup=admin_panel_kb(), parse_mode=ParseMode.HTML
    )
    await callback.answer()


@router.callback_query(F.data == "admin_stats")
async def admin_stats(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    stats = await db.get_stats()
    text = (
        f"<b>📊 Statistics</b>\n\n"
        f"👥 Users: <code>{stats['users']}</code>\n"
        f"📱 Numbers: <code>{stats['numbers']}</code>\n"
        f"📩 OTPs received: <code>{stats['otps']}</code>\n"
        f"💰 Total balance: <code>{stats['total_balance']}</code>"
    )
    await callback.message.edit_text(text, reply_markup=admin_panel_kb(), parse_mode=ParseMode.HTML)
    await callback.answer()


@router.callback_query(F.data == "admin_add_balance")
async def admin_add_balance_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_user_id)
    await callback.message.edit_text(
        "<b>➕ Add Balance</b>\n\nSend the <b>numeric User ID</b>:",
        parse_mode=ParseMode.HTML
    )
    await callback.answer()


@router.message(AdminStates.waiting_user_id)
async def admin_receive_user_id(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        user_id = int(message.text.strip())
        await state.update_data(target_user=user_id)
        await state.set_state(AdminStates.waiting_amount)
        await message.answer("Send the <b>amount</b> to add:", parse_mode=ParseMode.HTML)
    except ValueError:
        await message.answer("Invalid ID. Send a number.")


@router.message(AdminStates.waiting_amount)
async def admin_receive_amount(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        amount = int(message.text.strip())
        data = await state.get_data()
        target = data["target_user"]
        # Ensure user exists
        await db.get_or_create_user(target)
        success = await db.update_balance(target, amount, "admin_add", f"Admin {message.from_user.id}")
        await state.clear()
        if success:
            await message.answer(
                f"✅ Added <b>{amount}</b> credits to <code>{target}</code>",
                parse_mode=ParseMode.HTML, reply_markup=admin_panel_kb()
            )
        else:
            await message.answer("❌ Failed.", reply_markup=admin_panel_kb())
    except ValueError:
        await message.answer("Invalid amount.")


@router.callback_query(F.data == "admin_set_price")
async def admin_set_price_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_price_country)
    await callback.message.edit_text(
        "<b>💵 Set Price</b>\n\nSend country code (e.g. <code>GB</code>):",
        parse_mode=ParseMode.HTML
    )
    await callback.answer()


@router.message(AdminStates.waiting_price_country)
async def admin_receive_country(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    code = message.text.strip().upper()
    await state.update_data(country=code)
    await state.set_state(AdminStates.waiting_price_value)
    await message.answer(f"New price for <b>{code}</b> (credits):", parse_mode=ParseMode.HTML)


@router.message(AdminStates.waiting_price_value)
async def admin_receive_price(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        price = int(message.text.strip())
        data = await state.get_data()
        await db.set_price(data["country"], price)
        await state.clear()
        await message.answer(
            f"✅ {data['country']} = <code>{price}</code> credits",
            parse_mode=ParseMode.HTML, reply_markup=admin_panel_kb()
        )
    except ValueError:
        await message.answer("Invalid price.")


@router.callback_query(F.data == "admin_force_ranges")
async def admin_force_ranges(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    ranges = await zenex.get_active_ranges(force=True)
    await callback.answer(f"Refreshed • {len(ranges)} ranges", show_alert=True)


@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if not is_admin(message.from_user.id):
        return
    await message.answer("<b>🛡 Admin Panel</b>", reply_markup=admin_panel_kb(), parse_mode=ParseMode.HTML)