from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.enums import ParseMode

from config import settings
from database import db
from keyboards.inline import (
    main_menu_kb, countries_kb, services_kb, confirm_number_kb,
    my_numbers_kb, number_detail_kb, back_main_kb
)
from utils.zenex import zenex

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    user = await db.get_or_create_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.full_name
    )
    if user.get("is_banned"):
        await message.answer("🚫 You are banned.")
        return

    text = (
        f"<b>✨ Welcome to SexyFB Bot</b>\n\n"
        f"Premium virtual numbers + instant OTP delivery.\n\n"
        f"👤 {message.from_user.full_name}\n"
        f"💰 Balance: <code>{user['balance']}</code> credits\n\n"
        f"Choose an option below 👇"
    )
    is_admin = message.from_user.id in settings.admin_ids
    await message.answer(text, reply_markup=main_menu_kb(is_admin), parse_mode=ParseMode.HTML)


@router.callback_query(F.data == "back_main")
async def back_to_main(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    user = await db.get_user(callback.from_user.id)
    balance = user["balance"] if user else 0
    text = f"<b>🏠 Main Menu</b>\n\n💰 Balance: <code>{balance}</code> credits\n\nChoose an action:"
    is_admin = callback.from_user.id in settings.admin_ids
    await callback.message.edit_text(text, reply_markup=main_menu_kb(is_admin), parse_mode=ParseMode.HTML)
    await callback.answer()


@router.callback_query(F.data == "get_number")
async def start_get_number(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        "<b>🌍 Select Country</b>\n\nChoose the country for your virtual number:",
        reply_markup=countries_kb(), parse_mode=ParseMode.HTML
    )
    await callback.answer()


@router.callback_query(F.data.startswith("country:"))
async def select_country(callback: CallbackQuery, state: FSMContext):
    _, code, prefix = callback.data.split(":")
    await state.update_data(country_code=code, prefix=prefix)
    await callback.message.edit_text(
        f"<b>📱 Select Service</b>\n\nCountry: <b>{code}</b>\nChoose the service:",
        reply_markup=services_kb(code, prefix), parse_mode=ParseMode.HTML
    )
    await callback.answer()


@router.callback_query(F.data.startswith("service:"))
async def select_service(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split(":")
    code, prefix, service = parts[1], parts[2], parts[3]
    price = await db.get_price(code, settings.DEFAULT_NUMBER_PRICE)
    await state.update_data(country_code=code, prefix=prefix, service=service, price=price)
    await callback.message.edit_text(
        f"<b>✅ Confirm Purchase</b>\n\n"
        f"🌍 Country: <b>{code}</b>\n"
        f"📱 Service: <b>{service}</b>\n"
        f"💰 Price: <b>{price}</b> credits\n\nProceed?",
        reply_markup=confirm_number_kb(code, prefix, service, price),
        parse_mode=ParseMode.HTML
    )
    await callback.answer()


@router.callback_query(F.data.startswith("confirm:"))
async def confirm_and_buy(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split(":")
    code, prefix, service, price = parts[1], parts[2], parts[3], int(parts[4])
    user_id = callback.from_user.id

    balance = await db.get_balance(user_id)
    if balance < price:
        await callback.answer("❌ Insufficient balance!", show_alert=True)
        return

    await callback.message.edit_text("⏳ <b>Provisioning number...</b>", parse_mode=ParseMode.HTML)

    # Better range handling: try active ranges first for this country
    ranges = await zenex.get_active_ranges()
    range_to_use = f"{prefix}XXX"
    for r in ranges:
        r_prefix = str(r.get("range", "")).replace("X", "").replace("x", "")
        if r_prefix.startswith(prefix) or prefix.startswith(r_prefix[:len(prefix)]):
            range_to_use = r.get("range")
            break

    result = await zenex.provision_number(range_to_use)
    if not result:
        # fallback
        result = await zenex.provision_number(f"{prefix}XXX")

    if not result:
        await callback.message.edit_text(
            "❌ <b>Failed to provision</b>\nTry another country or later.",
            reply_markup=back_main_kb(), parse_mode=ParseMode.HTML
        )
        await callback.answer()
        return

    success = await db.update_balance(user_id, -price, "purchase", f"Number for {service}")
    if not success:
        await callback.message.edit_text("❌ Balance error.", reply_markup=back_main_kb())
        return

    full_num = result.get("number") or result.get("full_number") or result.get("copy")
    number_id = await db.add_number(
        user_id=user_id,
        full_number=full_num,
        country=result.get("country", code),
        operator=result.get("operator", "Unknown"),
        service=service,
        price=price
    )

    text = (
        f"<b>🎉 Number Ready!</b>\n\n"
        f"📱 <code>{full_num}</code>\n"
        f"🌍 {result.get('country', code)}\n"
        f"📡 {result.get('operator', '—')}\n"
        f"🛠 Service: <b>{service}</b>\n"
        f"💰 Charged: {price} credits\n\n"
        f"⏳ Auto-polling for OTP is active.\n"
        f"You will be notified automatically."
    )
    await callback.message.edit_text(text, reply_markup=number_detail_kb(number_id), parse_mode=ParseMode.HTML)
    await callback.answer("✅ Purchased!")


@router.callback_query(F.data == "my_numbers")
async def show_my_numbers(callback: CallbackQuery):
    numbers = await db.get_user_numbers(callback.from_user.id)
    if not numbers:
        await callback.message.edit_text(
            "<b>📱 My Numbers</b>\n\nNo numbers yet.",
            reply_markup=back_main_kb(), parse_mode=ParseMode.HTML
        )
    else:
        await callback.message.edit_text(
            f"<b>📱 My Numbers</b> ({len(numbers)})\n\nSelect one:",
            reply_markup=my_numbers_kb(numbers), parse_mode=ParseMode.HTML
        )
    await callback.answer()


@router.callback_query(F.data.startswith("view_num:"))
async def view_number(callback: CallbackQuery):
    number_id = int(callback.data.split(":")[1])
    num = await db.get_number_by_id(number_id)
    if not num or num["user_id"] != callback.from_user.id:
        await callback.answer("Not found", show_alert=True)
        return
    otps = await db.get_otps_for_number(number_id)
    otp_section = "\n\n<b>Latest OTPs:</b>\n" + "\n".join(
        f"• <code>{o['otp_text'][:80]}</code>" for o in otps[:5]
    ) if otps else "\n\n<i>No OTPs yet. Auto-polling is running...</i>"
    text = (
        f"<b>📱 Number</b>\n\n"
        f"<code>{num['full_number']}</code>\n"
        f"Country: {num['country']} | {num['operator']}\n"
        f"Service: <b>{num['service']}</b>\n"
        f"{otp_section}"
    )
    await callback.message.edit_text(text, reply_markup=number_detail_kb(number_id), parse_mode=ParseMode.HTML)
    await callback.answer()


@router.callback_query(F.data.startswith("refresh_otp:"))
async def refresh_otp(callback: CallbackQuery):
    number_id = int(callback.data.split(":")[1])
    num = await db.get_number_by_id(number_id)
    if not num or num["user_id"] != callback.from_user.id:
        await callback.answer("Not found", show_alert=True)
        return
    await callback.answer("🔄 Checking...")

    live = await zenex.fetch_otps()
    new_count = 0
    our = str(num["full_number"]).replace("+", "")
    for otp in live:
        otp_num = str(otp.get("number", "")).replace("+", "")
        if our[-8:] in otp_num or otp_num[-8:] in our:
            if await db.save_otp(number_id, otp.get("nid", ""), otp.get("otp", "")):
                new_count += 1

    otps = await db.get_otps_for_number(number_id)
    otp_section = "\n\n<b>OTPs:</b>\n" + "\n".join(
        f"• <code>{o['otp_text'][:80]}</code>" for o in otps[:8]
    ) if otps else "\n\n<i>Still waiting...</i>"
    text = (
        f"<b>📱 {num['full_number']}</b>\nService: {num['service']}\n{otp_section}\n\n"
        f"{'✅ ' + str(new_count) + ' new!' if new_count else '⏳ No new OTPs'}"
    )
    await callback.message.edit_text(text, reply_markup=number_detail_kb(number_id), parse_mode=ParseMode.HTML)


@router.callback_query(F.data.startswith("otp_history:"))
async def otp_history(callback: CallbackQuery):
    number_id = int(callback.data.split(":")[1])
    num = await db.get_number_by_id(number_id)
    if not num or num["user_id"] != callback.from_user.id:
        await callback.answer("Not found", show_alert=True)
        return
    otps = await db.get_otps_for_number(number_id)
    if not otps:
        text = f"<b>📋 History</b>\n\n<code>{num['full_number']}</code>\n\nNo OTPs yet."
    else:
        text = f"<b>📋 History</b>\n\n<code>{num['full_number']}</code>\n\n"
        for i, o in enumerate(otps, 1):
            text += f"{i}. <code>{o['otp_text']}</code>\n<i>{o['created_at'][:19]}</i>\n\n"
    await callback.message.edit_text(text, reply_markup=number_detail_kb(number_id), parse_mode=ParseMode.HTML)
    await callback.answer()


@router.callback_query(F.data == "balance")
async def show_balance(callback: CallbackQuery):
    balance = await db.get_balance(callback.from_user.id)
    text = (
        f"<b>💰 Your Balance</b>\n\n"
        f"Current: <code>{balance}</code> credits\n\n"
        f"Contact {settings.SUPPORT_USERNAME} to top up."
    )
    await callback.message.edit_text(text, reply_markup=back_main_kb(), parse_mode=ParseMode.HTML)
    await callback.answer()


@router.callback_query(F.data == "live_feed")
async def live_feed(callback: CallbackQuery):
    await callback.answer("📡 Loading...")
    feed = await zenex.get_global_feed()
    if not feed:
        text = "<b>📡 Global Live Feed</b>\n\nNo recent activity."
    else:
        text = "<b>📡 Global Live Feed</b>\n<i>Recent successful OTPs (masked)</i>\n\n"
        for item in feed[:10]:
            text += (
                f"🔹 <b>{item.get('service', '—')}</b> | {item.get('country', '')}\n"
                f"<code>{item.get('number', 'XXX')}</code>\n"
                f"{str(item.get('otp', ''))[:55]}...\n\n"
            )
    await callback.message.edit_text(text, reply_markup=back_main_kb(), parse_mode=ParseMode.HTML)


@router.callback_query(F.data == "live_traffic")
async def live_traffic(callback: CallbackQuery):
    await callback.answer("📊 Loading traffic...")
    ranges = await zenex.get_active_ranges(force=True)
    if not ranges:
        text = "<b>📊 Active Traffic</b>\n\nNo active ranges right now."
    else:
        text = "<b>📊 Active Traffic / Hot Ranges</b>\n\n"
        # Sort by hits descending if available
        sorted_r = sorted(ranges, key=lambda x: x.get("hits", 0), reverse=True)
        for r in sorted_r[:15]:
            text += (
                f"🔸 <code>{r.get('range')}</code>\n"
                f"   {r.get('service')} | {r.get('tag')} | Hits: <b>{r.get('hits', 0)}</b>\n\n"
            )
    await callback.message.edit_text(text, reply_markup=back_main_kb(), parse_mode=ParseMode.HTML)


@router.callback_query(F.data == "help")
async def help_cmd(callback: CallbackQuery):
    text = (
        "<b>ℹ️ Help</b>\n\n"
        "1️⃣ Get Number → Country → Service → Confirm\n"
        "2️⃣ Auto OTP polling runs in background\n"
        "3️⃣ You get notified + OTP appears in group\n"
        "4️⃣ Use Refresh / History anytime\n\n"
        f"🆘 Support: {settings.SUPPORT_USERNAME}\n"
        f"📢 Channel: {settings.CHANNEL_LINK}\n"
        f"💬 OTP Group: {settings.OTP_GROUP_LINK}"
    )
    await callback.message.edit_text(text, reply_markup=back_main_kb(), parse_mode=ParseMode.HTML)
    await callback.answer()