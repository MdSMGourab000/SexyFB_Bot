import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from config import settings
from database.db import init_db, get_active_numbers, save_otp, mark_nid_seen, is_nid_seen, get_number_by_id
from handlers import user, admin
from utils.zenex import zenex

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("SexyFB")

# Dual bots
main_bot: Bot = None
otp_bot: Bot = None


async def notify_user_and_group(number: dict, otp_text: str, nid: str):
    """Send OTP to the user via main bot and post to OTP group via otp_bot."""
    global main_bot, otp_bot
    user_id = number["user_id"]
    full_num = number["full_number"]
    service = number["service"]

    user_text = (
        f"<b>📩 New OTP Received!</b>\n\n"
        f"📱 <code>{full_num}</code>\n"
        f"🛠 Service: <b>{service}</b>\n\n"
        f"<code>{otp_text}</code>"
    )
    try:
        await main_bot.send_message(user_id, user_text, parse_mode=ParseMode.HTML)
    except Exception as e:
        logger.warning(f"Failed to notify user {user_id}: {e}")

    # Post to OTP group for better sync
    if otp_bot and settings.otp_group_id:
        group_text = (
            f"<b>🔥 Live OTP</b>\n\n"
            f"📱 <code>{full_num}</code>\n"
            f"Service: {service}\n"
            f"User ID: <code>{user_id}</code>\n\n"
            f"<code>{otp_text}</code>"
        )
        try:
            await otp_bot.send_message(settings.otp_group_id, group_text, parse_mode=ParseMode.HTML)
        except Exception as e:
            logger.warning(f"Failed to post to OTP group: {e}")


async def auto_otp_polling():
    """Background task: poll Zenex every few seconds and deliver OTPs automatically."""
    logger.info("Auto OTP polling started")
    while True:
        try:
            live_otps = await zenex.fetch_otps()
            if live_otps:
                active_nums = await get_active_numbers()
                for otp in live_otps:
                    nid = otp.get("nid") or ""
                    if not nid or await is_nid_seen(nid):
                        continue
                    otp_text = otp.get("otp", "")
                    otp_num = str(otp.get("number", "")).replace("+", "")

                    matched = None
                    for num in active_nums:
                        our = str(num["full_number"]).replace("+", "")
                        if our[-8:] in otp_num or otp_num[-8:] in our:
                            matched = num
                            break

                    if matched:
                        saved = await save_otp(matched["id"], nid, otp_text)
                        if saved:
                            await mark_nid_seen(nid)
                            await notify_user_and_group(matched, otp_text, nid)
                            logger.info(f"Auto-delivered OTP for {matched['full_number']}")
                    else:
                        # Mark seen even if no match to avoid reprocessing
                        await mark_nid_seen(nid)
        except Exception as e:
            logger.error(f"Polling error: {e}")

        await asyncio.sleep(settings.OTP_POLL_INTERVAL)


async def main():
    global main_bot, otp_bot

    await init_db()
    logger.info("Database ready")

    main_bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    if settings.OTP_BOT_TOKEN:
        otp_bot = Bot(
            token=settings.OTP_BOT_TOKEN,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML)
        )
        logger.info("OTP Group bot initialized")

    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(user.router)
    dp.include_router(admin.router)

    # Start background auto-polling
    asyncio.create_task(auto_otp_polling())

    logger.info("SexyFB_Bot v2 starting (main + auto OTP + group sync)...")
    await dp.start_polling(main_bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped")