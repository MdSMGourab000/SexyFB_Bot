import aiosqlite
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

DB_PATH = Path(__file__).parent.parent / "data" / "bot.db"


async def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                balance INTEGER DEFAULT 0,
                is_banned INTEGER DEFAULT 0,
                joined_at TEXT,
                last_active TEXT
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS numbers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                full_number TEXT,
                country TEXT,
                operator TEXT,
                service TEXT,
                status TEXT DEFAULT 'active',
                price INTEGER,
                created_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS otps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                number_id INTEGER,
                nid TEXT UNIQUE,
                otp_text TEXT,
                created_at TEXT,
                notified INTEGER DEFAULT 0,
                FOREIGN KEY (number_id) REFERENCES numbers (id)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                amount INTEGER,
                type TEXT,
                description TEXT,
                created_at TEXT
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS prices (
                country_code TEXT PRIMARY KEY,
                price INTEGER
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS seen_nids (
                nid TEXT PRIMARY KEY,
                seen_at TEXT
            )
        """)
        await db.commit()


async def get_or_create_user(user_id: int, username: str = None, full_name: str = None) -> Dict:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            if row:
                await db.execute(
                    "UPDATE users SET last_active = ?, username = COALESCE(?, username), full_name = COALESCE(?, full_name) WHERE user_id = ?",
                    (datetime.utcnow().isoformat(), username, full_name, user_id)
                )
                await db.commit()
                return dict(row)
            now = datetime.utcnow().isoformat()
            await db.execute(
                "INSERT INTO users (user_id, username, full_name, balance, joined_at, last_active) VALUES (?, ?, ?, 0, ?, ?)",
                (user_id, username, full_name, now, now)
            )
            await db.commit()
            return {"user_id": user_id, "username": username, "full_name": full_name, "balance": 0, "is_banned": 0, "joined_at": now, "last_active": now}


async def get_user(user_id: int) -> Optional[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def update_balance(user_id: int, amount: int, tx_type: str, description: str = "") -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            if not row:
                return False
            new_balance = row[0] + amount
            if new_balance < 0:
                return False
            await db.execute("UPDATE users SET balance = ? WHERE user_id = ?", (new_balance, user_id))
            await db.execute(
                "INSERT INTO transactions (user_id, amount, type, description, created_at) VALUES (?, ?, ?, ?, ?)",
                (user_id, amount, tx_type, description, datetime.utcnow().isoformat())
            )
            await db.commit()
            return True


async def get_balance(user_id: int) -> int:
    user = await get_user(user_id)
    return user["balance"] if user else 0


async def add_number(user_id: int, full_number: str, country: str, operator: str, service: str, price: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            """INSERT INTO numbers (user_id, full_number, country, operator, service, status, price, created_at)
               VALUES (?, ?, ?, ?, ?, 'active', ?, ?)""",
            (user_id, full_number, country, operator, service, price, datetime.utcnow().isoformat())
        )
        await db.commit()
        return cursor.lastrowid


async def get_user_numbers(user_id: int, limit: int = 20) -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM numbers WHERE user_id = ? ORDER BY created_at DESC LIMIT ?", (user_id, limit)
        ) as cursor:
            return [dict(r) for r in await cursor.fetchall()]


async def get_number_by_id(number_id: int) -> Optional[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM numbers WHERE id = ?", (number_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def get_active_numbers() -> List[Dict]:
    """All currently active numbers for auto-polling matching."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM numbers WHERE status = 'active'") as cursor:
            return [dict(r) for r in await cursor.fetchall()]


async def save_otp(number_id: int, nid: str, otp_text: str) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute(
                "INSERT INTO otps (number_id, nid, otp_text, created_at, notified) VALUES (?, ?, ?, ?, 0)",
                (number_id, nid, otp_text, datetime.utcnow().isoformat())
            )
            await db.commit()
            return True
        except aiosqlite.IntegrityError:
            return False


async def mark_otp_notified(nid: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE otps SET notified = 1 WHERE nid = ?", (nid,))
        await db.commit()


async def get_otps_for_number(number_id: int) -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM otps WHERE number_id = ? ORDER BY created_at DESC", (number_id,)
        ) as cursor:
            return [dict(r) for r in await cursor.fetchall()]


async def is_nid_seen(nid: str) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT 1 FROM seen_nids WHERE nid = ?", (nid,)) as cursor:
            return await cursor.fetchone() is not None


async def mark_nid_seen(nid: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO seen_nids (nid, seen_at) VALUES (?, ?)",
            (nid, datetime.utcnow().isoformat())
        )
        await db.commit()


async def set_price(country_code: str, price: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO prices (country_code, price) VALUES (?, ?)",
            (country_code.upper(), price)
        )
        await db.commit()


async def get_price(country_code: str, default: int = 50) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT price FROM prices WHERE country_code = ?", (country_code.upper(),)
        ) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else default


async def get_stats() -> Dict[str, Any]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM users") as c:
            users = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM numbers") as c:
            numbers = (await c.fetchone())[0]
        async with db.execute("SELECT SUM(balance) FROM users") as c:
            total_balance = (await c.fetchone())[0] or 0
        async with db.execute("SELECT COUNT(*) FROM otps") as c:
            otps = (await c.fetchone())[0]
        return {"users": users, "numbers": numbers, "total_balance": total_balance, "otps": otps}