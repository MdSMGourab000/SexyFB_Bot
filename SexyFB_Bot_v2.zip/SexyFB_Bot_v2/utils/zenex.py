import aiohttp
import time
from typing import Optional, Dict, List
from config import settings

_ranges_cache: Dict = {"data": [], "ts": 0}


class ZenexAPI:
    def __init__(self):
        self.base = settings.ZENEX_BASE_URL.rstrip("/")
        self.headers = {
            "mapikey": settings.ZENEX_API_KEY,
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

    async def provision_number(self, range_prefix: str, is_national: bool = False, remove_plus: bool = False) -> Optional[Dict]:
        url = f"{self.base}/v1/getnum"
        payload = {"range": range_prefix, "is_national": is_national, "remove_plus": remove_plus}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, headers=self.headers, timeout=30) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("meta", {}).get("status") == "success":
                            return data.get("data")
        except Exception:
            pass
        return None

    async def fetch_otps(self) -> List[Dict]:
        url = f"{self.base}/v1/numsuccess/info"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=self.headers, timeout=15) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("meta", {}).get("status") == "success":
                            return data.get("data", {}).get("otps", [])
        except Exception:
            pass
        return []

    async def get_active_ranges(self, force: bool = False) -> List[Dict]:
        now = time.time()
        if not force and _ranges_cache["data"] and (now - _ranges_cache["ts"]) < settings.RANGES_CACHE_SECONDS:
            return _ranges_cache["data"]

        url = f"{self.base}/v1/active-ranges"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=self.headers, timeout=15) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("success"):
                            ranges = data.get("data", {}).get("active_ranges", [])
                            _ranges_cache["data"] = ranges
                            _ranges_cache["ts"] = now
                            return ranges
        except Exception:
            pass
        return _ranges_cache["data"] or []

    async def get_global_feed(self) -> List[Dict]:
        url = "https://www.zenexnetwork.com/api/v1/global-broadcast"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=15) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("success"):
                            return data.get("data", [])
        except Exception:
            pass
        return []


zenex = ZenexAPI()