# 🔥 SexyFB_Bot v2

Premium Telegram virtual number + OTP bot powered by **Zenex Core API**.

## New in v2
- ✅ **Auto OTP polling** (background task, notifies user instantly)
- ✅ Better range handling (uses live active-ranges first)
- ✅ Active traffic sorted by hits
- ✅ User-friendly buttons + Channel / OTP Group links
- ✅ Dual bot support (Main bot + OTP Group bot for perfect sync)
- ✅ 24/7 ready (Docker + Railway / Render)

## Quick Deploy (24/7 on Railway)

1. Create account on [railway.app](https://railway.app)
2. New Project → Deploy from GitHub → select this repo
3. Add environment variables (from `.env.example`)
4. Deploy. Railway keeps it running 24/7.

Or use Render.com / any Docker host.

## Local Run

```bash
cp .env.example .env
# Edit .env → put real ADMIN_IDS (numeric!), OTP_GROUP_ID, tokens already filled
pip install -r requirements.txt
python bot.py
```

## Important Setup Steps

1. Get numeric User IDs of admins from @userinfobot and put in `ADMIN_IDS`
2. Create a Telegram group for OTPs
3. Add **@SexyFB_OTP_Bot** as admin in that group
4. Get the group ID (forward a message to @userinfobot or use a bot that shows chat id) → put in `OTP_GROUP_ID`
5. (Optional) Force users to join your channel

## Security

Never commit the real `.env` file.  
After testing, **regenerate both bot tokens** in @BotFather because they were shared.

## Admins

- @MdGourab00
- @SuperStarGourab01
