from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    BOT_TOKEN: str
    OTP_BOT_TOKEN: str = ""
    ADMIN_IDS: str = ""
    ZENEX_API_KEY: str
    ZENEX_BASE_URL: str = "https://api.zenexnetwork.com"
    CHANNEL_USERNAME: str = "@SexyFB_Bot"
    OTP_GROUP_ID: str = ""
    DEFAULT_NUMBER_PRICE: int = 50
    MIN_BALANCE_TO_BUY: int = 50
    OTP_POLL_INTERVAL: int = 4
    RANGES_CACHE_SECONDS: int = 120
    SUPPORT_USERNAME: str = "@MdGourab00"
    CHANNEL_LINK: str = "https://t.me/SexyFB_Bot"
    OTP_GROUP_LINK: str = "https://t.me/SexyFB_OTP_Bot"

    @property
    def admin_ids(self) -> List[int]:
        if not self.ADMIN_IDS:
            return []
        return [int(x.strip()) for x in self.ADMIN_IDS.split(",") if x.strip().isdigit()]

    @property
    def otp_group_id(self) -> int | None:
        if not self.OTP_GROUP_ID:
            return None
        try:
            return int(self.OTP_GROUP_ID)
        except ValueError:
            return None

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()