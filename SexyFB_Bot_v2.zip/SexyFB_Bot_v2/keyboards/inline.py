from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import List, Dict
from config import settings


def main_menu_kb(is_admin: bool = False) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text="🌍 Get Number", callback_data="get_number"),
        InlineKeyboardButton(text="📱 My Numbers", callback_data="my_numbers")
    )
    b.row(
        InlineKeyboardButton(text="💰 Balance", callback_data="balance"),
        InlineKeyboardButton(text="📡 Live Feed", callback_data="live_feed")
    )
    b.row(
        InlineKeyboardButton(text="📊 Active Traffic", callback_data="live_traffic"),
        InlineKeyboardButton(text="ℹ️ Help", callback_data="help")
    )
    b.row(
        InlineKeyboardButton(text="📢 Channel", url=settings.CHANNEL_LINK),
        InlineKeyboardButton(text="💬 OTP Group", url=settings.OTP_GROUP_LINK)
    )
    if is_admin:
        b.row(InlineKeyboardButton(text="🛡 Admin Panel", callback_data="admin_panel"))
    return b.as_markup()


COUNTRIES = [
    {"code": "GB", "name": "🇬🇧 United Kingdom", "prefix": "447"},
    {"code": "US", "name": "🇺🇸 United States", "prefix": "1"},
    {"code": "NL", "name": "🇳🇱 Netherlands", "prefix": "316"},
    {"code": "DE", "name": "🇩🇪 Germany", "prefix": "49"},
    {"code": "FR", "name": "🇫🇷 France", "prefix": "33"},
    {"code": "ES", "name": "🇪🇸 Spain", "prefix": "34"},
    {"code": "IT", "name": "🇮🇹 Italy", "prefix": "39"},
    {"code": "PL", "name": "🇵🇱 Poland", "prefix": "48"},
    {"code": "SE", "name": "🇸🇪 Sweden", "prefix": "46"},
    {"code": "CA", "name": "🇨🇦 Canada", "prefix": "1"},
]


def countries_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for c in COUNTRIES:
        b.button(text=c["name"], callback_data=f"country:{c['code']}:{c['prefix']}")
    b.adjust(2)
    b.row(InlineKeyboardButton(text="« Back to Menu", callback_data="back_main"))
    return b.as_markup()


SERVICES = [
    "Telegram", "WhatsApp", "Instagram", "Facebook", "Google",
    "Twitter/X", "Discord", "TikTok", "Amazon", "Microsoft",
    "Apple", "Uber", "Any / Other"
]


def services_kb(country_code: str, prefix: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for svc in SERVICES:
        b.button(text=svc, callback_data=f"service:{country_code}:{prefix}:{svc}")
    b.adjust(2)
    b.row(InlineKeyboardButton(text="« Countries", callback_data="get_number"))
    return b.as_markup()


def confirm_number_kb(country_code: str, prefix: str, service: str, price: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text=f"✅ Confirm • {price} credits",
        callback_data=f"confirm:{country_code}:{prefix}:{service}:{price}"
    ))
    b.row(InlineKeyboardButton(text="« Cancel", callback_data="get_number"))
    return b.as_markup()


def my_numbers_kb(numbers: List[Dict]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for n in numbers[:12]:
        short = n["full_number"][-8:] if len(n["full_number"]) > 8 else n["full_number"]
        b.button(text=f"📱 ...{short} | {n['service']}", callback_data=f"view_num:{n['id']}")
    b.adjust(1)
    b.row(InlineKeyboardButton(text="« Menu", callback_data="back_main"))
    return b.as_markup()


def number_detail_kb(number_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text="🔄 Refresh OTPs", callback_data=f"refresh_otp:{number_id}"),
        InlineKeyboardButton(text="📋 History", callback_data=f"otp_history:{number_id}")
    )
    b.row(InlineKeyboardButton(text="« My Numbers", callback_data="my_numbers"))
    return b.as_markup()


def admin_panel_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text="➕ Add Balance", callback_data="admin_add_balance"),
        InlineKeyboardButton(text="📊 Stats", callback_data="admin_stats")
    )
    b.row(
        InlineKeyboardButton(text="💵 Set Price", callback_data="admin_set_price"),
        InlineKeyboardButton(text="🔄 Force Ranges", callback_data="admin_force_ranges")
    )
    b.row(InlineKeyboardButton(text="« Menu", callback_data="back_main"))
    return b.as_markup()


def back_main_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text="« Main Menu", callback_data="back_main"))
    return b.as_markup()